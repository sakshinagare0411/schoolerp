from django.shortcuts import render
from django.http import HttpResponse,HttpRequest

def index(request):
    return render(request,'index.html')

def notice(request):
    return render(request,'notice.html')

def about(request):
    return render(request,'about.html')

def contact(request):
    return render(request,'contact.html')

def achievements(request):
    return render(request,'achievements.html')


# Create your views here.
