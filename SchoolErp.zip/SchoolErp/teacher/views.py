from django.shortcuts import render
from django.http import HttpResponse

def teacher(request):
    return HttpResponse('hello teacher')

# Create your views here.
