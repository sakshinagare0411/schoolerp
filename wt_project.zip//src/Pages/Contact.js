import React from "react";

const Contact = () => {
  return (
    <div>
      <header>
        <h1>Contact Us</h1>
      </header>
      <div class="container">
        <h1>Fill out the form below:</h1>
        <form action="#" method="post">
          <label htmlFor="name">Name:</label><br />
          <input type="text" id="name" name="name" required /><br />
          <label htmlFor="email">Email:</label><br />
          <input type="email" id="email" name="email" required /><br />
          <label htmlFor="message">Message:</label><br />
          <textarea id="message" name="message" rows="4" required></textarea><br />
          <input type="submit" value="Submit" />
        </form>
      </div>
    </div>
  );
};

export default Contact;