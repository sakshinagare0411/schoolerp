// Home.js

import React from "react";

const Home = () => {
  return (
    <div>
      <h1>Home</h1>
      <p>
        Welcome to our school website. Here you can find information about our
        school and its activities.
      </p>
    </div>
  );
};

export default Home;
