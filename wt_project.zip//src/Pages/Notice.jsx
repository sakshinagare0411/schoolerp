import React from "react";
import "./Notice.css"
const Notice = () => {
  return (
<div>
    <div className="notice-board">
    <h1>Notice Board</h1>
    <ul className="notice-list">
      <li>
        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Non, pariatur?</p>
      </li>
      <li>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Non, aspernatur?</p>
      </li>
      <li>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nesciunt, expedita.</p>
      </li>
      <li>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. In, iste?</p>
      </li>
      <li>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis, rem!</p>
      </li>
    </ul>
  </div>
</div>
  )
}
export default Notice;