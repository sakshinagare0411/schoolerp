import React from "react";

function Teacher() {
    return(
        <div class="margin-top-50 width-100">
    <div class="container1">
      <div class="login1">
       {/* <img src="images/s4.jpg" alt=""> */}
        <div class="form-box">
          <h2>Teachers Portal</h2>
          <h1 id="title">Sign Up</h1>
          <form action="">
            <div class="input-group">
              <div class="input-field" id="namefield">
                <i class="fa fa-user"></i>
                <input type="text" placeholder="Name" />
              </div>

              <div class="input-field">
                {/* <i class="fa-solid fa-envelope"></i> */}
                <i class="fa fa-envelope"></i>
                <input type="email" placeholder="Email" />
              </div>

              <div class="input-field">
                <i class="fa fa-lock"></i>
                <input type="password" placeholder="Password" />
              </div>
              <p>Lost Password <a href="#"> Click Here!</a></p>
            </div>

            <div class="btn-field">
              <button type="button " id="signupbtn">Sign Up</button>
              <button type="button" id="signinbtn" class="disable">Sign In</button>
            </div>
          </form>
        </div>
      </div>

    </div>
  </div>
    );
}

export default Teacher;