
import React, { useRef } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Header from "./Components/Header.jsx";
import Nav from "./Components/Nav.jsx";
import Carousel from "./Components/Carousel.jsx";
import Section from "./Components/Section.jsx";
import Student from "./Pages/Student.js";
import Teacher from "./Pages/Teacher.jsx";
import Notice from "./Pages/Notice.jsx";
import Attendence from "./Components/Attendence.jsx";
import Exam from "./Components/Exam.jsx";
import Studtimetable from "./Components/Studtimetable.jsx";
import Teachertimetable from "./Components/Teachertimetable.jsx";
import Home from "./Pages/Home.js";
import Aboutus from "./Pages/Aboutus.js";
import Contact from "./Pages/Contact.js"
import Error from "./Pages/Error.js";
import "../public/style.css";
function App() {
  
  return (
    <BrowserRouter>
    <Header />
    <Nav />
    <Carousel />
      <Routes>
        <Route path="/" element={<div></div>} />
        <Route path="/home" element={<Home />} />
        <Route path="/about" element={<Aboutus />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/notice" element={<Notice />} />
        <Route path="/studentportal" element={<Student />} />
        <Route path="/teacherportal" element={<Teacher />} />
        <Route path="*" element={<Error />} />
        {/* Add more routes here */}
      </Routes>
      
    </BrowserRouter>
    
  );
}

export default App;