import React from "react";
import ReactDOM from "react-dom";
import App from "./App";

import Section from "./Components/Section.jsx";
import Attendence from "./Components/Attendence.jsx";
import Exam from "./Components/Exam.jsx";
import Studtimetable from "./Components/Studtimetable.jsx";
import Teachertimetable from "./Components/Teachertimetable.jsx";
import "../public/style.css";
ReactDOM.render(
  <div>
    <App />
      <Section />

      <Attendence />
      <Exam />
      <Studtimetable />
      <Teachertimetable />
      </div>,document.getElementById("root")
)