import React from "react";
import { Link } from "react-router-dom";
import "./Nav.css";
function  Nav(){
  
    return(
    <nav className="navbar navbar-expand-lg navbar-light bg-light ">
    <div className="container">
      <a className="navbar-brand fw-bold" href="#">School</a>
      <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
        aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span className="navbar-toggler-icon"></span>
      </button>
      <div className="collapse navbar-collapse" id="navbarNav">
        <ul className="navbar-nav m-auto mb-2 mb-lg-0 center">
          <li className="nav-item mx-3">
            <Link to="/home" className="nav-link active" aria-current="page">Home</Link>
          </li>
          <li className="nav-item mx-3">
            <Link to="/about" className="nav-link">About</Link>
          </li>
          <li className="nav-item mx-3">
            <Link to="/notice" className="nav-link">Notice Board</Link>
          </li>
          <li className="nav-item mx-3">
            <Link to="/contact" className="nav-link">Contact</Link>
          </li>
        </ul>

        <ul className="navbar-nav mr-auto mb-2 mb-lg-0">
          <li className="nav-item">
            <Link to="/studentportal" className="nav-link active mx-3" aria-current="page">Student<br /> Portal</Link>
          </li>
          <li className="nav-item">
            <Link to="/teacherportal" className="nav-link active mx-3" aria-current="page">Teacher<br /> Portal</Link>
          </li>
          <li className="nav-item">
            <Link to="/achievements" className="nav-link active mx-3" aria-current="page">Achivements</Link>
          </li>
        </ul>

      </div>
    </div>
  </nav>
);
}

export default Nav;