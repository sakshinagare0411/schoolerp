import React from "react";

function Exam()
{
    return(
    <div class="margin-top-50 width-100">
    <div class="table-container">
      <h2>Exam Timetable</h2>
      <table>
        <thead>
          <tr>
            <th>Date</th>
            <th>Day</th>
            <th>Time</th>
            <th>Subject</th>

          </tr>
        </thead>
        <tr>
          <td>10/01/24</td>
          <td>Monday</td>
          <td>9:00am - 10:00am</td>
          <td>Math</td>

        </tr>
        <tr>
          <td>10/01/24</td>
          <td>Monday</td>
          <td>10:30am - 11:30am</td>
          <td>English</td>

        </tr>
        <tr>
          <td>10/01/24</td>
          <td>Tuesday</td>
          <td>9:00am - 10:00am</td>
          <td>Science</td>

        </tr>
        <tr>
          <td>10/01/24</td>
          <td>Tuesday</td>
          <td>10:30am - 11:30am</td>
          <td>History</td>

        </tr>
        <tr>
          <td>10/01/24</td>
          <td>Wednesday</td>
          <td>9:00am - 10:00am</td>
          <td>Geography</td>

        </tr>
        <tr>
          <td>10/01/24</td>
          <td>Wednesday</td>
          <td>10:30am - 11:30am</td>
          <td>Art</td>

        </tr>
      </table>
    </div>
  </div>
  )
}

export default Exam;