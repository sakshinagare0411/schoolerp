import React from "react";

function Attendence() {
    return(
        
  <div class="margin-top-50 width-100">
  <div class="table-container">
    <h2>Attendance Record for April 2024</h2>

    <table>
      <thead>
        <tr>
          <th>Sr. No.</th>
          <th>Date</th>
          <th>Attendance</th>
        </tr>
      </thead>
      <tbody>

        {/* Day 1 */}
        <tr>
          <td>1</td>
          <td>01/04/24</td>
          <td></td> {/* Insert attendance status here */}
        </tr>

        {/* Day 2 */}
        <tr>
          <td>2</td>
          <td>02/04/24</td>
          <td></td> {/* Insert attendance status here */}
        </tr>

        {/* Day 3 */}
        <tr>
          <td>3</td>
          <td>03/04/24</td>
          <td></td> {/* Insert attendance status here */}
        </tr>

        {/* Continue for remaining days (up to Day 31) */}
        {/* Replace with actual data if applicable */}

        {/* Day 4 */}
        <tr>
          <td>4</td>
          <td>04/04/24</td>
          <td></td> {/* Insert attendance status here */}
        </tr>

        {/* Day 5 */}
        <tr>
          <td>5</td>
          <td>05/04/24</td>
          <td></td> {/* Insert attendance status here */}
        </tr>

        <tr>
          <td>5</td>
          <td>05/04/24</td>
          <td></td> {/* Insert attendance status here */}
        </tr>

        <tr>
          <td>5</td>
          <td>05/04/24</td>
          <td></td> {/* Insert attendance status here */}
        </tr>

        <tr>
          <td>5</td>
          <td>05/04/24</td>
          <td></td> {/* Insert attendance status here */}
        </tr>

        <tr>
          <td>5</td>
          <td>05/04/24</td>
          <td></td> {/* Insert attendance status here */}
        </tr>

        <tr>
          <td>5</td>
          <td>05/04/24</td>
          <td></td> 
        </tr>
        {/* Continue for all 31 days of April 2024 */}
        {/* Example: Hardcoded for demonstration */}

        {/* Day 31 */}
        <tr>
          <td>31</td>
          <td>30/04/24</td>
          <td></td> {/* Insert attendance status here */}
        </tr>
      </tbody>
    </table>
  </div>
</div>
    );
}

export default Attendence;