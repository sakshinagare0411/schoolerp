import React from "react";

function Header() {
    return(
        <header class="text-center header-social-icon text-lg-start   bg-primary text-white">
    <div class="container">
      {/*      Section: Social media */}
      <section class="d-flex justify-content-center justify-content-lg-between p-1 border-bottom">
       {/*     Left */}
        <div class="me-5 d-lg-block">
          <span class="mx-2"><i class="fa fa-phone mx-1">+91245524644524541</i></span>
          <span> <i class="fa fa-calendar mx-1"></i> Mon-fri: 10:00-04:00</span>
        </div>
        {/*    Left  */}

        {/* Right */}  
        <div>
          <a href="" class="me-4 text-reset">
            <i class="fa fa-facebook"></i>
          </a>
          <a href="" class="me-4 text-reset">
            <i class="fa fa-twitter"></i>
          </a>
          <a href="" class="me-4 text-reset">
            <i class="fa fa-google"></i>
          </a>
          <a href="" class="me-4 text-reset">
            <i class="fa fa-instagram"></i>
          </a>
          <a href="" class="me-4 text-reset">
            <i class="fa fa-linkedin"></i>
          </a>

        </div>
         {/* Right */}
      </section>
       {/* Section: Social media */}
    </div>
  </header>
    );
}

export default Header;