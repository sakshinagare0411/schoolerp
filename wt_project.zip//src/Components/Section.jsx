import React from "react";

function Section() {
    return(
        <div class="width-100 margin-top-50">
    <div class="container">

      <div class="width-33">
        <div class="latest-news">

          <div class="heading-sect">
            <h3 class="head-title">Latest New</h3>
          </div>

          <marquee direction="up">
            <ul class="latest-news-ul">
              <li>February 18, 2024 - Winter Olympics Closing Ceremony in Beijing, China</li>
              <li>November 8, 2024 - U.S. Presidential Election</li>
              <li>December 31, 2024 - New Year's Eve</li>
              <li>March 14, 2025 - Pi Day (3/14/25)</li>
              <li>June 6, 2026 - 100th Anniversary of D-Day</li>
              <li>October 1, 2027 - 100th Anniversary of the Founding of the People's Republic of China</li>
            </ul>
          </marquee>

        </div>
      </div>

      <div class="width-33">
        <div class="event-list">

          <div class="heading-sect">
            <h3 class="head-title">Upcoming Events/Exam Time Table</h3>
          </div>
          <ul class="upcoming-event-list">
            <li><span class="event-date">25<br />April</span><span>aqjgxjcheusiahs askjdhszkjc asjdhgasuwoeqi</span> </li>
            <li><span class="event-date">25<br />April</span><span>aqjgxjcheusiahs askjdhszkjc asjdhgasuwoeqi</span> </li>
            <li><span class="event-date">25<br />April</span><span>aqjgxjcheusiahs askjdhszkjc asjdhgasuwoeqi</span> </li>
            <li><span class="event-date">25<br />April</span><span>aqjgxjcheusiahs askjdhszkjc asjdhgasuwoeqi</span> </li>
            <li><span class="event-date">25<br />April</span><span>aqjgxjcheusiahs askjdhszkjc asjdhgasuwoeqi</span> </li>
          </ul>
        </div>
      </div>

      <div class="width-33">
        <div class="notice-board">
          <div class="heading-sect">
            <h3 class="head-title">Notice Board</h3>
          </div>

          <ul class="notice-board-list">
            <li>Parent-Teacher Meeting on [date]: Discuss your child's progress, [time].</li>

            <li>School Trip to [destination] on [date]: Return permission slips by [deadline].</li>

            <li>Remember to wear [specific uniform items] daily during school hours.</li>

            <li> Join us for [event name] on [date]: More details coming soon!</li>


          </ul>

        </div>
      </div>
    </div>
  </div>
    );
}

export default Section;