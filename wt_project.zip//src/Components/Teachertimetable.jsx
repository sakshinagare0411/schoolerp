import React from "react";

function Teachertimetable()
{
    return(
        <div class="margin-top-50 width-100">
    <div class="table-container">
      <h2>Time Table-Teacher</h2>
      <table>
        <thead class="time-table">
          <tr>
            <th>Day</th>
            <th>9:30-10:20</th>
            <th>10:20-11:10</th>
            <th>11:10-12:00</th>
            <th>12:00-12:40</th>
            <th>12:40-1:30</th>
            <th>1:30-2:20</th>
            <th>2:20-3:10</th>
            <th>3:10-4:00</th>
          </tr>
        </thead>
        <tr>
          <td class="highlight"><b>Monday</b></td>
          <td>5th-A<br />Eng</td>
          <td>6th-B<br />Mat</td>
          <td></td>
          <td rowspan="6" class="special"><b>LUNCH</b></td>
          <td colspan="3" class="special">break</td>
          <td>7th-C<br />Phy</td>
        </tr>
        <tr>
          <td class="highlight"><b>Tuesday</b></td>
          <td colspan="3" class="special">7th-B<br />LAB</td>
          <td>8th-A<br />Eng</td>
          <td>break</td>
          <td>break</td>
          <td class="special">9th-A<br />Marathi</td>
        </tr>
        <tr>
          <td class="highlight"><b>Wednesday</b></td>
          <td>Mat</td>
          <td>Phy</td>
          <td>Eng</td>
          <td>Che</td>
          <td colspan="3">LIBRARY</td>
        </tr>
        <tr>
          <td class="highlight"><b>Thursday</b></td>
          <td>Phy</td>
          <td>Eng</td>
          <td>Che</td>
          <td colspan="3" class="special">LAB</td>
          <td>Mat</td>
        </tr>
        <tr>
          <td class="highlight"><b>Friday</b></td>
          <td colspan="3" class="special">LAB</td>
          <td>Mat</td>
          <td>Che</td>
          <td>Eng</td>
          <td>Phy</td>
        </tr>
        <tr>
          <td class="highlight"><b>Saturday</b></td>
          <td>Eng</td>
          <td>Che</td>
          <td>Mat</td>
          <td colspan="3">SEMINAR</td>
          <td class="special">SPORTS</td>
        </tr>
      </table>
    </div>
  </div>
    );
}

export default Teachertimetable;